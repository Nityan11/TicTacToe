package com.example.tictactoe

import android.content.DialogInterface
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.*
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import kotlinx.android.synthetic.main.activity_main.* //only in gradle build version 30 not 31, so change in project structure


class MainActivity : AppCompatActivity() {
    private var playerOneTurn = true
    private var playerOneMoves = mutableListOf<Int>() //tells what moves player1 made
    private var playerTwoMoves = mutableListOf<Int>() //tells what moves player2 made
    var count = 0
    private var boardIds = mutableMapOf<Int,MutableList<Int>>()//stores if ids of board rows
    //all possible winning combinations of ids(buttons)
    private val possibleWins:Array<List<Int>> = arrayOf(
        //rows
        listOf(1,2,3),
        listOf(4,5,6),
        listOf(7,8,9),
        //columns
        listOf(1,4,7),
        listOf(2,5,8),
        listOf(3,6,9),
        //diagonals
        listOf(1,5,9),
        listOf(3,5,7)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupBoard()
    }

    //as in design ids couldnt be named by numbers, so i used dynamic: this function sets up the board
    private fun setupBoard(){
        var counter = 1 //naming of buttons:ids

        val params1 = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0
        )
        val params2  = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.MATCH_PARENT,
        )
        for(i in 1..3){
            var row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutParams = params1
            params1.weight = 1.0F
            var list = mutableListOf<Int>()
             for(i in 1..3){
                 val button = Button(this)
                 button.id = counter
                 list.add(counter)
                 button.textSize = 42.0F
                 button.setTextColor(ContextCompat.getColor(this,R.color.teal_200))

                 button.layoutParams = params2
                 params2.weight = 1.0F
                 button.setOnClickListener{
                     count++
                     recordMove(button)
                 }
                 row.addView(button)
                 counter++
                 boardIds.put(row.id, list)
             }
            board.addView(row)
        }
    }

    private fun recordMove(button: Button){
        val id = button.id
        if(playerOneTurn){
            playerOneMoves.add(id)
            button.text = "O"
            button.isEnabled = false
            if(CheckWin(playerOneMoves)){
                dialogAlertMaker("******* WINNER *******", " Congratulations! ${name_one.text} has won the game! Lets play another game.")
                //showMessage(name_one)
            }else if(count == 9){
                dialogAlertMaker("Draw Match", "Its a draw! Lets try again. Click the NEW GAME button to play again.")
                //showMessage(null)
            }
            else{
                playerOneTurn = false
                togglePlayerTurn(player2,player1)//highlights the next player to tell that its their turn
            }
        }else{
            playerTwoMoves.add(id)
            button.text = "X"
            button.isEnabled = false
            if(CheckWin(playerTwoMoves)){
                dialogAlertMaker("*********** WINNER ***********", " Congratulations! ${name_two.text} has won the game! Lets play another game.")
                //showMessage(name_two)
            }else if(count == 9){
                dialogAlertMaker("Draw Match", "Its a draw! Lets try again. Click the NEW GAME button to play again.")
                //showMessage(null)
            }
            else{
                playerOneTurn = true
                togglePlayerTurn(player1,player2)
            }

        }

    }
    private fun CheckWin(moves: MutableList<Int>): Boolean{
        var won  = false
        if(moves.size>=3){
            run loop@{
                possibleWins.forEach{
                    if(moves.containsAll(it)){
                        won = true
                        return@loop//we mean return to @loop label when loop ends..as this is a lambda so we have to return like this
                    }
                }
            }
        }
        return won
    }
    /*private fun showMessage(player:EditText?){
        if(player == null){
            Toast.makeText(this,"Its a draw!", Toast.LENGTH_SHORT).show()
        }
        else{
            var player_name = player.text.toString()
            if(player_name.isBlank()){
                player_name = player.hint.toString()
            }
            Toast.makeText(this,"Congratulations! ${player_name} has Won the game.", Toast.LENGTH_SHORT).show()
        }

    }*/
    private fun togglePlayerTurn(playerOn: TextView, playeroff: TextView){
        playeroff.setTextColor(ContextCompat.getColor(this, R.color.black))
        playeroff.setTypeface(null, Typeface.NORMAL)
        playerOn.setTextColor(ContextCompat.getColor(this,R.color.teal_200))
        playerOn.setTypeface(null,Typeface.BOLD)
    }

    private fun dialogAlertMaker( title: String, message: String) {
        val builder = AlertDialog.Builder(this) //making an object of alert dailog
        //configuring the alert dialog
        with(builder) {
            setTitle(title)
            setMessage(message)

            setPositiveButton("NEW GAME", object : DialogInterface.OnClickListener {
                override fun onClick(dialog: DialogInterface?, which: Int) {

                    //ResetBoard()
                }
            })
            //OR
            /*setPositiveButton(getString(R.string.yes)){ dialog, which->
                    cityData.clear()
                    saveCities()
            }*/
            setNegativeButton("CANCEL", object : DialogInterface.OnClickListener {
                override fun onClick(dialog: DialogInterface?, which: Int) {
                    //does nothing
                }
            })
        }
        val dialog = builder.create()
        dialog.show()
    }
    private fun ResetBoard(){
        count = 0
        name_one.setText("")
        name_two.setText("")
        togglePlayerTurn(player1,player2)
        boardIds.keys.forEach{
            var ll = findViewById<LinearLayout>(it)
            for(i in 0..ll.getChildCount()-1){
                    ll.getChildAt(i).isVisible = false
            }
        }
        playerOneTurn = true
        playerOneMoves.clear()
        playerTwoMoves.clear()
    }
}